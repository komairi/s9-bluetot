# Ultra S9 Protocol Monitor v9.1

Versi diagnostik untuk memantau protokol BLE Ultra tanpa mengirim perintah WRITE.

Fungsi:
- Scan BLE dan pilih perangkat Ultra.
- Connect dan membaca seluruh GATT.
- Membaca characteristic yang punya READ.
- Mengaktifkan NOTIFY UART `6E400003`.
- Mengaktifkan NOTIFY proprietary Ultra `0000FF01`.
- Menampilkan HEX, panjang paket, dan ASCII untuk setiap data masuk.
- Tidak mengirim paket waktu atau command WRITE ke jam.

Urutan penggunaan:
1. Install APK.
2. CARI ULTRA.
3. Pilih perangkat Ultra.
4. HUBUNGKAN & BACA GATT.
5. MONITOR NOTIFY UART + FF01.
6. Biarkan beberapa detik, lalu kirim screenshot log yang muncul.


## v9.2
- Monitor notify 6E400003 dan FF01.
- Probe aman F3 00 pada 6E400002 untuk meminta info perangkat.
- Menampilkan HEX dan ASCII balasan.
- Tidak mengirim perintah pengaturan waktu.

Urutan uji: Cari ULTRA -> Hubungkan & Baca GATT -> Monitor Notify -> CEK INFO PERANGKAT (F3 00).
