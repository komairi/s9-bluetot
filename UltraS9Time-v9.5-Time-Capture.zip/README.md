# Ultra S9 Time Capture v9.5

Diagnostic build based on v9.4. It monitors the confirmed HryFine-style BLE UART path and parses DF/FD frames. It does not contain a SET TIME command.

## Test sequence
1. CARI ULTRA
2. Select ULTRA
3. HUBUNGKAN & BACA GATT
4. MONITOR NOTIFY UART + FF01
5. BIND + CEK INFO (03 00 → F3 00)
6. AMBIL DATA 30 DETIK
7. Send the bottom log screenshot.

The 30-second capture only records notifications and parsed frame fields. It does not send any time-setting or firmware command.
