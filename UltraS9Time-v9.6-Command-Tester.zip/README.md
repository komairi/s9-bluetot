# Ultra S9 Command Tester v9.6

Diagnostic BLE app for the Ultra/HryFine-family watch.

Features:
- Scan and connect to BLE Ultra.
- Discover GATT services.
- Enable 6E400003 and FF01 notifications.
- BIND 03 00 and request device info F3 00.
- Parse DF/FD frames and auto-ACK DF frames on 6E400003.
- 30-second passive capture.
- Manual command tester for 6E400002 using CMD/SUB/PAYLOAD HEX.
- CMD 13 (OTA) is blocked.

This build does NOT contain a SET TIME command. The command tester is intended to test only protocol commands we understand or candidates we explicitly decide to test.
