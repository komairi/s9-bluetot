# Ultra S9 Time

Aplikasi Android sederhana untuk mendeteksi dan menghubungkan smartwatch Ultra S9 melalui Bluetooth Low Energy (BLE), lalu membaca daftar GATT service/characteristic.

## Penting

Versi 1 **belum mengirim perintah perubahan waktu ke jam**. Ultra S9 yang beredar menggunakan firmware/protokol yang bisa berbeda-beda. Aplikasi ini sengaja menampilkan UUID characteristic agar kita bisa mengidentifikasi protokol jam yang kamu punya tanpa mengarang paket Bluetooth.

## Cara build

1. Buka folder ini di Android Studio.
2. Tunggu Gradle selesai sync.
3. Hubungkan HP Android untuk testing.
4. Build > Build APK(s).

## Cara tes

1. Aktifkan Bluetooth HP.
2. Jalankan aplikasi.
3. Tekan `CARI ULTRA S9`.
4. Pilih perangkat jam.
5. Tekan `HUBUNGKAN`.
6. Lihat bagian `GATT` untuk daftar service dan characteristic.

Setelah kamu kirim screenshot bagian GATT tersebut, kita bisa lanjut membuat perintah `SET WAKTU SEKARANG` yang benar untuk Ultra S9 kamu.
