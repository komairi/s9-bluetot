# Ultra S9 Time Guess v9.7

Versi eksperimen paling minim risiko untuk mencoba sinkronisasi waktu.

- Jalur: 6E400002 write / 6E400003 notify.
- BIND 03 00 dan F3 00 tetap tersedia.
- CMD 13/OTA tetap diblokir.
- Tombol KNOWN SETTING mengirim hanya command yang sudah terdokumentasi: 02 0A 01.
- Tombol TIME GUESS A mengirim tebakan CMD 01 / SUB 00 dengan payload 7 byte: year-2000, month, day, hour, minute, second, weekday.
- TIME GUESS A meminta konfirmasi sebelum dikirim.
- Tidak ada factory reset atau OTA command.

Catatan: command sinkronisasi waktu untuk varian Ultra ini belum terkonfirmasi. TIME GUESS A adalah eksperimen dan bisa saja diabaikan perangkat.
