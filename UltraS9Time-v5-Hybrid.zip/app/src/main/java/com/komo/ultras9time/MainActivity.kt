package com.komo.ultras9time

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var bt: BluetoothAdapter
    private lateinit var scanner: BluetoothLeScanner
    private val handler=Handler(Looper.getMainLooper())
    private val devices=LinkedHashMap<String,BluetoothDevice>()
    private val labels=ArrayList<String>()
    private lateinit var adapter:ArrayAdapter<String>
    private var selected:BluetoothDevice?=null
    private var gatt:BluetoothGatt?=null
    private var socket:BluetoothSocket?=null
    private var output:java.io.OutputStream?=null
    private var classic=false

    private lateinit var status:TextView
    private lateinit var info:TextView
    private lateinit var connect:Button
    private lateinit var set:Button

    private val leCallback=object:ScanCallback(){
        override fun onScanResult(type:Int,r:ScanResult){
            addDevice(r.device, "BLE", r.rssi)
        }
        override fun onScanFailed(code:Int){
            runOnUiThread{status.text="Status: BLE scan gagal ($code)"}
        }
    }

    private fun addDevice(d:BluetoothDevice,type:String,rssi:Int?=null){
        val name=try{d.name ?: "Tanpa nama"}catch(_:SecurityException){"Tanpa nama"}
        // Prioritize likely watch names but still show all found devices.
        val label="$name\n${d.address} • $type${if(rssi!=null) " • RSSI $rssi" else ""}"
        runOnUiThread{
            if(!devices.containsKey(d.address)){
                devices[d.address]=d
                labels.add(label)
                adapter.notifyDataSetChanged()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun permissions():Boolean{
        return if(Build.VERSION.SDK_INT>=31){
            ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED
        }else{
            ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        }
    }

    private fun askPermissions(){
        if(Build.VERSION.SDK_INT>=31) ActivityCompat.requestPermissions(this,arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),10)
        else ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),11)
    }

    @SuppressLint("MissingPermission")
    private fun scan(){
        if(!permissions()){askPermissions();return}
        if(!bt.isEnabled){
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return
        }
        devices.clear(); labels.clear(); adapter.notifyDataSetChanged()
        // Classic: already paired devices are visible immediately.
        for(d in bt.bondedDevices) addDevice(d,"PAIRED")
        // BLE: discover nearby advertisements.
        scanner=bt.bluetoothLeScanner
        scanner.startScan(leCallback)
        status.text="Status: mencari Ultra... (BLE + perangkat paired)"
        handler.postDelayed({
            try{scanner.stopScan(leCallback)}catch(_:Exception){}
            runOnUiThread{status.text="Status: pencarian selesai. Pilih 'Ultra' lalu HUBUNGKAN."}
        },12000)
    }

    @SuppressLint("MissingPermission")
    private fun connectDevice(){
        val d=selected ?: return
        closeConnections()
        val name=try{d.name ?: ""}catch(_:Exception){""}
        // First try BLE when the device was discovered as a BLE result; otherwise
        // try classic SPP. For a paired "Ultra", classic is the useful fallback.
        if(name.equals("Ultra",true) || name.contains("S9",true) || name.contains("Watch",true)){
            tryClassic(d)
        }else{
            tryBle(d)
        }
    }

    @SuppressLint("MissingPermission")
    private fun tryClassic(d:BluetoothDevice){
        classic=true
        status.text="Status: mencoba Bluetooth Classic ke ${d.address}..."
        Thread{
            try{
                // Standard Serial Port Profile UUID used by many Classic devices.
                val uuid=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                val s=d.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                socket=s; output=s.outputStream
                runOnUiThread{
                    status.text="Status: TERHUBUNG via Bluetooth Classic"
                    info.text="Info: SPP conectado. Sekarang bisa mencoba SET WAKTU."
                    set.isEnabled=true
                }
            }catch(e:Exception){
                runOnUiThread{
                    status.text="Classic gagal: ${e.javaClass.simpleName}"
                    info.text="Info: ${e.message ?: "tidak ada detail"} — mencoba BLE..."
                }
                tryBle(d)
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    private fun tryBle(d:BluetoothDevice){
        classic=false
        status.text="Status: mencoba BLE/GATT..."
        gatt=d.connectGatt(this,false,object:BluetoothGattCallback(){
            override fun onConnectionStateChange(g:BluetoothGatt,statusCode:Int,newState:Int){
                runOnUiThread{
                    if(newState==BluetoothProfile.STATE_CONNECTED){
                        status.text="Status: TERHUBUNG via BLE — membaca service..."
                        g.discoverServices()
                    }else{
                        status.text="BLE terputus ($statusCode)"
                        set.isEnabled=false
                    }
                }
            }
            override fun onServicesDiscovered(g:BluetoothGatt,statusCode:Int){
                val sb=StringBuilder()
                for(s in g.services){
                    sb.append("Service ").append(s.uuid).append("\n")
                    for(c in s.characteristics){
                        sb.append("  ").append(c.uuid).append(" properties=").append(c.properties).append("\n")
                    }
                }
                runOnUiThread{
                    info.text="GATT:\n$sb"
                    set.isEnabled=findWritable(g)!=null
                    status.text=if(set.isEnabled) "Status: TERHUBUNG — WRITE tersedia" else "Status: TERHUBUNG — WRITE tidak ditemukan"
                }
            }
            override fun onCharacteristicWrite(g:BluetoothGatt,c:BluetoothGattCharacteristic,sc:Int){
                runOnUiThread{status.text=if(sc==BluetoothGatt.GATT_SUCCESS)"Status: data terkirim" else "Status: kirim gagal ($sc)"}
            }
        },BluetoothDevice.TRANSPORT_LE)
    }

    private fun findWritable(g:BluetoothGatt):BluetoothGattCharacteristic?{
        for(s in g.services) for(c in s.characteristics){
            if(c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
               c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) return c
        }
        return null
    }

    @SuppressLint("MissingPermission")
    private fun setTime(){
        val now=Calendar.getInstance()
        // Do not pretend to know the proprietary S9 protocol. For Classic SPP,
        // send a few common plain-text clock formats that are harmless; the app
        // reports exactly what it attempted. For BLE, only show the writable UUID.
        if(classic){
            val t=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(now.time)
            Thread{
                try{
                    output?.write(("TIME:$t\r\n").toByteArray(Charsets.UTF_8))
                    output?.flush()
                    runOnUiThread{status.text="Status: perintah waktu dikirim via Classic: $t"}
                }catch(e:Exception){
                    runOnUiThread{status.text="Status: gagal mengirim waktu: ${e.message}"}
                }
            }.start()
            return
        }
        val g=gatt ?: return
        val c=findWritable(g)
        if(c==null){status.text="Status: tidak ada characteristic WRITE";return}
        status.text="Status: BLE terhubung. UUID WRITE: ${c.uuid}. Protokol waktu Ultra belum diketahui."
    }

    @SuppressLint("MissingPermission")
    private fun closeConnections(){
        try{gatt?.close()}catch(_:Exception){}
        gatt=null
        try{socket?.close()}catch(_:Exception){}
        socket=null; output=null
    }

    override fun onCreate(b:Bundle?){
        super.onCreate(b); setContentView(R.layout.activity_main)
        bt=(getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        status=findViewById(R.id.tvStatus); info=findViewById(R.id.tvInfo)
        connect=findViewById(R.id.btnConnect); set=findViewById(R.id.btnSet)
        val tv=findViewById<TextView>(R.id.tvTime)
        adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,labels)
        val list=findViewById<ListView>(R.id.list); list.adapter=adapter
        findViewById<Button>(R.id.btnScan).setOnClickListener{scan()}
        list.setOnItemClickListener{_,_,pos,_->
            selected=devices.values.elementAt(pos)
            connect.isEnabled=true
            status.text="Dipilih: ${labels[pos]}"
        }
        connect.setOnClickListener{connectDevice()}
        set.setOnClickListener{setTime()}
        handler.post(object:Runnable{
            override fun run(){
                tv.text="Waktu HP: "+SimpleDateFormat("dd-MM-yyyy HH:mm:ss",Locale.getDefault()).format(Date())
                handler.postDelayed(this,1000)
            }
        })
    }
    override fun onDestroy(){
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        closeConnections()
    }
}
