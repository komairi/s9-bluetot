# Ultra S9 Time v5 — Hybrid Bluetooth

Versi ini dibuat karena perangkat pengguna muncul dengan nama **Ultra** tetapi tidak berhasil terhubung pada versi BLE-only.

Perubahan:
- Scan BLE
- Tampilkan perangkat Bluetooth yang sudah paired
- Untuk nama `Ultra`, `S9`, atau `Watch`, aplikasi mencoba **Bluetooth Classic SPP terlebih dahulu**, lalu fallback ke BLE.
- Untuk perangkat BLE, membaca GATT service/characteristic.
- Tombol SET WAKTU tersedia jika koneksi berhasil.

Catatan penting:
Perintah waktu smartwatch Ultra S9 biasanya proprietary. Versi ini belum mengklaim kompatibilitas penuh. Jika Classic berhasil terhubung tetapi jam tidak berubah setelah SET WAKTU, berarti jam menggunakan protokol khusus dan perlu identifikasi lebih lanjut.
