# Ultra S9 UART Diagnostic v9

Perbaikan v9: tombol NOTIFY sekarang memprioritaskan UART Ultra 6e400003 dan tidak lagi memilih Battery Level 00002a19.

UART yang ditemukan:
- Service 6e400001-b5a3-f393-e0a9-e50e24dcca9f
- Notify 6e400003-b5a3-f393-e0a9-e50e24dcca9f
- Write 6e400002-b5a3-f393-e0a9-e50e24dcca9f

Setelah terhubung, tekan AKTIFKAN NOTIFY ULTRA (6E400003). Status harus menunjukkan 6e400003. Jika muncul NOTIFY HEX, kirim screenshot. Jangan WRITE data waktu dulu.
