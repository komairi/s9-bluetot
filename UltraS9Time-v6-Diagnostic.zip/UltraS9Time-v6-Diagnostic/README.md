# Ultra S9 Diagnostic v6

Aplikasi diagnostik untuk mencari jalur komunikasi Ultra S9.

Fitur:
- scan BLE dan perangkat Bluetooth yang sudah paired
- koneksi GATT
- daftar Service dan Characteristic
- penanda READ / WRITE / WRITE_NO_RESPONSE / NOTIFY / INDICATE
- baca characteristic READ dan tampilkan data HEX
- aktifkan NOTIFY/INDICATE dan tampilkan data HEX yang masuk
- tidak mengirim paket waktu acak

Setelah terhubung:
1. Kirim screenshot daftar GATT.
2. Tekan BACA DATA READABLE, tunggu selesai, kirim screenshot.
3. Tekan AKTIFKAN NOTIFY / INDICATE, tunggu beberapa detik, kirim screenshot bila ada data.

Android GATT memang menggunakan characteristic sebagai elemen data dan property READ/WRITE/NOTIFY/INDICATE untuk menentukan operasi yang tersedia.
