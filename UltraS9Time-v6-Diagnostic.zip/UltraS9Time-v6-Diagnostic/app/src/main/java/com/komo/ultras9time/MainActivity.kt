package com.komo.ultras9time

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var bt: BluetoothAdapter
    private lateinit var scanner: BluetoothLeScanner
    private val handler=Handler(Looper.getMainLooper())
    private val devs=LinkedHashMap<String,BluetoothDevice>()
    private val labels=ArrayList<String>()
    private val chars=ArrayList<BluetoothGattCharacteristic>()
    private val readQueue=ArrayList<BluetoothGattCharacteristic>()
    private var readIndex=0
    private var gatt:BluetoothGatt?=null
    private var selected:BluetoothDevice?=null
    private lateinit var listAdapter:ArrayAdapter<String>
    private lateinit var status:TextView
    private lateinit var info:TextView
    private lateinit var connect:Button
    private lateinit var read:Button
    private lateinit var notify:Button

    private fun permitted()=if(Build.VERSION.SDK_INT>=31)
        ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED
    else ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
    private fun requestPerm(){if(Build.VERSION.SDK_INT>=31) ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),10) else ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),11)}

    private val scanCb=object:ScanCallback(){
        @SuppressLint("MissingPermission") override fun onScanResult(t:Int,r:ScanResult){
            val d=r.device; val name=try{d.name ?: r.scanRecord?.deviceName ?: "Tanpa nama"}catch(_:Exception){"Tanpa nama"}
            runOnUiThread{if(!devs.containsKey(d.address)){devs[d.address]=d;labels.add("$name\n${d.address} • BLE • RSSI ${r.rssi}");listAdapter.notifyDataSetChanged()}}
        }
        override fun onScanFailed(c:Int){runOnUiThread{status.text="Status: scan gagal $c"}}
    }

    @SuppressLint("MissingPermission") private fun scan(){
        if(!permitted()){requestPerm();return}; if(!bt.isEnabled){startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return}
        devs.clear();labels.clear();listAdapter.notifyDataSetChanged()
        for(d in bt.bondedDevices){val n=try{d.name?:"Paired"}catch(_:Exception){"Paired"};devs[d.address]=d;labels.add("$n\n${d.address} • PAIRED")}
        listAdapter.notifyDataSetChanged(); scanner=bt.bluetoothLeScanner;scanner.startScan(scanCb);status.text="Status: mencari Ultra..."
        handler.postDelayed({try{scanner.stopScan(scanCb)}catch(_:Exception){};runOnUiThread{status.text="Status: scan selesai"}},12000)
    }

    @SuppressLint("MissingPermission") private fun connect(){
        val d=selected?:return;gatt?.close();chars.clear();status.text="Status: menghubungkan ${d.address}..."
        gatt=d.connectGatt(this,false,object:BluetoothGattCallback(){
            override fun onConnectionStateChange(g:BluetoothGatt,s:Int,state:Int){runOnUiThread{if(state==BluetoothProfile.STATE_CONNECTED){status.text="Status: TERHUBUNG — membaca GATT...";g.discoverServices()}else{status.text="Status: terputus ($s)";read.isEnabled=false;notify.isEnabled=false}}}
            override fun onServicesDiscovered(g:BluetoothGatt,s:Int){
                if(s!=BluetoothGatt.GATT_SUCCESS){status.text="GATT gagal $s";return};val sb=StringBuilder();chars.clear()
                for(svc in g.services){sb.append("\nSERVICE ").append(svc.uuid).append("\n");for(c in svc.characteristics){chars.add(c);sb.append("  CHAR ").append(c.uuid).append(" [").append(props(c.properties)).append("]\n")}}
                runOnUiThread{info.text=sb.toString();read.isEnabled=chars.any{it.properties and 2!=0};notify.isEnabled=chars.any{it.properties and 16!=0||it.properties and 32!=0};status.text="Status: TERHUBUNG — ${chars.size} characteristic"}
            }
            override fun onCharacteristicRead(g:BluetoothGatt,c:BluetoothGattCharacteristic,s:Int){runOnUiThread{info.append("\nREAD ${c.uuid} = ${hex(c.value?:byteArrayOf())}");readIndex++;handler.postDelayed({readNext()},250)}}
            override fun onCharacteristicChanged(g:BluetoothGatt,c:BluetoothGattCharacteristic){runOnUiThread{info.append("\nNOTIFY ${c.uuid} = ${hex(c.value?:byteArrayOf())}")}}
        },BluetoothDevice.TRANSPORT_LE)
    }
    private fun props(p:Int):String{val a=ArrayList<String>();if(p and 2!=0)a.add("READ");if(p and 4!=0)a.add("WRITE_NR");if(p and 8!=0)a.add("WRITE");if(p and 16!=0)a.add("NOTIFY");if(p and 32!=0)a.add("INDICATE");return a.joinToString("|")}
    private fun hex(b:ByteArray)=b.joinToString(" "){String.format("%02X",it.toInt() and 255)}
    @SuppressLint("MissingPermission") private fun readAll(){readQueue.clear();readQueue.addAll(chars.filter{it.properties and 2!=0});readIndex=0;readNext()}
    @SuppressLint("MissingPermission") private fun readNext(){val g=gatt?:return;if(readIndex>=readQueue.size){status.text="READ selesai";return};status.text="READ ${readQueue[readIndex].uuid}";g.readCharacteristic(readQueue[readIndex])}
    @SuppressLint("MissingPermission") private fun enableNotify(){val g=gatt?:return;val c=chars.firstOrNull{it.properties and 16!=0||it.properties and 32!=0}?:return;g.setCharacteristicNotification(c,true);val d=c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));if(d!=null){d.value=if(c.properties and 32!=0)BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;g.writeDescriptor(d)};status.text="Notify/Indicate aktif: ${c.uuid}"}

    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);bt=(getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter;status=findViewById(R.id.tvStatus);info=findViewById(R.id.tvInfo);connect=findViewById(R.id.btnConnect);read=findViewById(R.id.btnRead);notify=findViewById(R.id.btnNotify);val tv=findViewById<TextView>(R.id.tvTime);listAdapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,labels);val list=findViewById<ListView>(R.id.list);list.adapter=listAdapter;findViewById<Button>(R.id.btnScan).setOnClickListener{scan()};list.setOnItemClickListener{_,_,p,_->selected=devs.values.elementAt(p);connect.isEnabled=true;status.text="Dipilih: ${labels[p]}"};connect.setOnClickListener{connect()};read.setOnClickListener{readAll()};notify.setOnClickListener{enableNotify()};handler.post(object:Runnable{override fun run(){tv.text="Waktu HP: "+SimpleDateFormat("dd-MM-yyyy HH:mm:ss",Locale.getDefault()).format(Date());handler.postDelayed(this,1000)}})}
    override fun onDestroy(){super.onDestroy();handler.removeCallbacksAndMessages(null);try{gatt?.close()}catch(_:Exception){}}
}
