# Ultra S9 Time

Aplikasi Android sederhana untuk mendeteksi dan menghubungkan smartwatch Ultra S9 melalui Bluetooth Low Energy (BLE), lalu membaca daftar GATT service/characteristic.

## Versi 2 — Gradle 8.9

Versi ini sudah diperbaiki untuk error:

`Minimum supported Gradle version is 8.9. Current version is 8.7`

Project memakai Android Gradle Plugin 8.7.3 dan workflow GitHub Actions secara eksplisit memakai **Gradle 8.9**.

## Fitur

- Cari perangkat Bluetooth/BLE
- Pilih Ultra S9
- Hubungkan ke jam
- Menampilkan waktu HP
- Membaca GATT Service & Characteristic
- Tombol SET WAKTU SEKARANG sebagai tahap identifikasi protokol

## Penting

Versi ini belum mengirim perintah perubahan waktu ke jam. Ultra S9 yang beredar dapat menggunakan firmware/protokol berbeda. Setelah jam berhasil terhubung, kirim screenshot bagian GATT agar perintah set waktu dapat dibuat berdasarkan karakteristik yang benar.

## Build di GitHub

Upload isi ZIP ini ke repository GitHub. Workflow:

`.github/workflows/build.yml`

akan otomatis memakai **Gradle 8.9**, Java 17, lalu menghasilkan:

`app/build/outputs/apk/debug/app-debug.apk`

APK tersedia di bagian **Artifacts** pada hasil GitHub Actions.
