package com.komo.ultras9time

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var bt: BluetoothAdapter
    private lateinit var scanner: BluetoothLeScanner
    private val handler = Handler(Looper.getMainLooper())
    private val devs = LinkedHashMap<String, BluetoothDevice>()
    private val labels = ArrayList<String>()
    private val chars = ArrayList<BluetoothGattCharacteristic>()
    private val readQueue = ArrayList<BluetoothGattCharacteristic>()
    private val notifyTargets = ArrayList<BluetoothGattCharacteristic>()
    private var readIndex = 0
    private var notifyIndex = 0
    private var gatt: BluetoothGatt? = null
    private var selected: BluetoothDevice? = null
    private lateinit var listAdapter: ArrayAdapter<String>
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var connect: Button
    private lateinit var read: Button
    private lateinit var notify: Button
    private lateinit var clear: Button
    private lateinit var probe: Button
    private lateinit var ack: Button
    private lateinit var bind: Button

    companion object {
        private const val UART_SERVICE = "6e400001-b5a3-f393-e0a9-e50e24dcca9f"
        private const val UART_NOTIFY = "6e400003-b5a3-f393-e0a9-e50e24dcca9f"
        private const val UART_WRITE = "6e400002-b5a3-f393-e0a9-e50e24dcca9f"
        private const val ULTRA_SERVICE = "0000ff00-0000-1000-8000-00805f9b34fb"
        private const val ULTRA_NOTIFY = "0000ff01-0000-1000-8000-00805f9b34fb"
        private const val CCCD = "00002902-0000-1000-8000-00805f9b34fb"
        private const val ACK_AUTO = true
    }

    private fun permitted() = if (Build.VERSION.SDK_INT >= 31)
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestPerm() {
        if (Build.VERSION.SDK_INT >= 31) ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10
        ) else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 11)
    }

    private val scanCb = object : ScanCallback() {
        @SuppressLint("MissingPermission") override fun onScanResult(t: Int, r: ScanResult) {
            val d = r.device
            val name = try { d.name ?: r.scanRecord?.deviceName ?: "Tanpa nama" } catch (_: Exception) { "Tanpa nama" }
            runOnUiThread {
                if (!devs.containsKey(d.address)) {
                    devs[d.address] = d
                    labels.add("$name\n${d.address} • BLE • RSSI ${r.rssi}")
                    listAdapter.notifyDataSetChanged()
                }
            }
        }
        override fun onScanFailed(c: Int) { runOnUiThread { status.text = "Status: scan gagal $c" } }
    }

    @SuppressLint("MissingPermission") private fun scan() {
        if (!permitted()) { requestPerm(); return }
        if (!bt.isEnabled) { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return }
        devs.clear(); labels.clear(); listAdapter.notifyDataSetChanged()
        for (d in bt.bondedDevices) {
            val n = try { d.name ?: "Paired" } catch (_: Exception) { "Paired" }
            devs[d.address] = d
            labels.add("$n\n${d.address} • PAIRED")
        }
        listAdapter.notifyDataSetChanged()
        scanner = bt.bluetoothLeScanner
        scanner.startScan(scanCb)
        status.text = "Status: mencari Ultra..."
        handler.postDelayed({
            try { scanner.stopScan(scanCb) } catch (_: Exception) {}
            runOnUiThread { status.text = "Status: scan selesai" }
        }, 12000)
    }

    @SuppressLint("MissingPermission") private fun connect() {
        val d = selected ?: return
        gatt?.close()
        chars.clear(); notifyTargets.clear(); notifyIndex = 0
        status.text = "Status: menghubungkan ${d.address}..."
        gatt = d.connectGatt(this, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, s: Int, state: Int) {
                runOnUiThread {
                    if (state == BluetoothProfile.STATE_CONNECTED) {
                        status.text = "Status: TERHUBUNG — membaca GATT..."
                        g.discoverServices()
                    } else {
                        status.text = "Status: terputus ($s)"
                        read.isEnabled = false
                        notify.isEnabled = false
                        probe.isEnabled = false
                        ack.isEnabled = false
                        bind.isEnabled = false
                    }
                }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, s: Int) {
                if (s != BluetoothGatt.GATT_SUCCESS) { runOnUiThread { status.text = "GATT gagal $s" }; return }
                val sb = StringBuilder()
                chars.clear()
                for (svc in g.services) {
                    sb.append("\nSERVICE ").append(svc.uuid).append("\n")
                    for (c in svc.characteristics) {
                        chars.add(c)
                        sb.append("  CHAR ").append(c.uuid).append(" [").append(props(c.properties)).append("]\n")
                    }
                }
                runOnUiThread {
                    info.text = sb.toString()
                    read.isEnabled = chars.any { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 }
                    notify.isEnabled = findNotify(UART_NOTIFY) != null || findNotify(ULTRA_NOTIFY) != null
                    probe.isEnabled = findChar(UART_WRITE) != null
                    ack.isEnabled = findChar(UART_WRITE) != null
                    bind.isEnabled = findChar(UART_WRITE) != null
                    status.text = "Status: TERHUBUNG — ${chars.size} characteristic"
                }
            }

            override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, s: Int) {
                runOnUiThread {
                    appendLog("READ ${c.uuid} [status=$s] = ${hex(c.value ?: byteArrayOf())}")
                    readIndex++
                    handler.postDelayed({ readNext() }, 250)
                }
            }

            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
                val data = c.value ?: byteArrayOf()
                runOnUiThread {
                    appendLog("NOTIFY ${c.uuid} (${data.size} byte) = ${hex(data)} | ASCII=${ascii(data)}")
                    status.text = "DATA MASUK: ${shortUuid(c.uuid)} • ${data.size} byte"
                }
                if (c.uuid.toString().equals(UART_NOTIFY, true) && ACK_AUTO && data.size >= 9 && (data[0].toInt() and 0xFF) == 0xDF) {
                    sendAckForDf(g, data)
                }
            }

            override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, s: Int) {
                if (s == BluetoothGatt.GATT_SUCCESS) {
                    notifyIndex++
                    handler.postDelayed({ enableNextNotify() }, 400)
                } else {
                    runOnUiThread { appendLog("NOTIFY ERROR ${d.characteristic.uuid} descriptor status=$s") }
                    notifyIndex++
                    handler.postDelayed({ enableNextNotify() }, 400)
                }
            }
        }, BluetoothDevice.TRANSPORT_LE)
    }


    @SuppressLint("MissingPermission") private fun sendAckForDf(g: BluetoothGatt, df: ByteArray) {
        val write = findChar(UART_WRITE) ?: return
        val ackedLen = df.size
        val ack = byteArrayOf(
            0xFD.toByte(), 0x00, 0x05, 0x00,
            df[4], df[5],
            ((ackedLen shr 8) and 0xFF).toByte(),
            (ackedLen and 0xFF).toByte(), 0x01
        )
        var sum = 0
        for (b in ack) sum = (sum + (b.toInt() and 0xFF)) and 0xFF
        ack[3] = sum.toByte()
        write.writeType = if (write.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        write.value = ack
        val ok = g.writeCharacteristic(write)
        runOnUiThread { appendLog("AUTO-ACK ${if (ok) "TERKIRIM" else "GAGAL"} = ${hex(ack)}") }
    }

    private fun props(p: Int): String {
        val a = ArrayList<String>()
        if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) a.add("READ")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) a.add("WRITE_NR")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) a.add("WRITE")
        if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) a.add("NOTIFY")
        if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) a.add("INDICATE")
        return a.joinToString("|")
    }

    private fun hex(b: ByteArray) = b.joinToString(" ") { String.format("%02X", it.toInt() and 255) }
    private fun ascii(b: ByteArray) = b.map { if (it.toInt() in 32..126) it.toInt().toChar() else '.' }.joinToString("")
    private fun shortUuid(u: UUID) = u.toString().substring(4, 8)

    private fun appendLog(text: String) {
        val t = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        info.append("\n[$t] $text")
    }

    @SuppressLint("MissingPermission") private fun readAll() {
        readQueue.clear()
        readQueue.addAll(chars.filter { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 })
        readIndex = 0
        appendLog("=== MULAI READ SEMUA CHARACTERISTIC ===")
        readNext()
    }

    @SuppressLint("MissingPermission") private fun readNext() {
        val g = gatt ?: return
        if (readIndex >= readQueue.size) { status.text = "READ selesai"; return }
        status.text = "READ ${readQueue[readIndex].uuid}"
        g.readCharacteristic(readQueue[readIndex])
    }

    private fun findChar(uuid: String): BluetoothGattCharacteristic? = chars.firstOrNull { it.uuid.toString().equals(uuid, true) }

    private fun findNotify(uuid: String): BluetoothGattCharacteristic? = chars.firstOrNull {
        it.uuid.toString().equals(uuid, true) &&
            (it.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
    }

    @SuppressLint("MissingPermission") private fun enableMonitor() {
        val g = gatt ?: return
        notifyTargets.clear()
        findNotify(UART_NOTIFY)?.let { notifyTargets.add(it) }
        findNotify(ULTRA_NOTIFY)?.let { if (notifyTargets.none { x -> x.uuid == it.uuid }) notifyTargets.add(it) }
        if (notifyTargets.isEmpty()) {
            status.text = "Tidak ditemukan UART/FF01 NOTIFY"
            return
        }
        notifyIndex = 0
        appendLog("=== MONITOR NOTIFY UART + FF01 ===")
        appendLog("Target: " + notifyTargets.joinToString(", ") { it.uuid.toString() })
        enableNextNotify()
    }

    @SuppressLint("MissingPermission") private fun enableNextNotify() {
        val g = gatt ?: return
        if (notifyIndex >= notifyTargets.size) {
            status.text = "MONITOR AKTIF — tunggu data dari Ultra..."
            appendLog("=== SEMUA NOTIFY AKTIF ===")
            return
        }
        val c = notifyTargets[notifyIndex]
        val ok = g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(UUID.fromString(CCCD))
        appendLog("Aktifkan ${c.uuid}: set=$ok")
        if (d == null) {
            appendLog("CCCD tidak ditemukan untuk ${c.uuid}")
            notifyIndex++
            handler.postDelayed({ enableNextNotify() }, 400)
            return
        }
        d.value = if (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0 &&
            c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0)
            BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        val writeOk = g.writeDescriptor(d)
        if (!writeOk) {
            appendLog("writeDescriptor gagal langsung untuk ${c.uuid}")
            notifyIndex++
            handler.postDelayed({ enableNextNotify() }, 500)
        }
    }


    private fun makeFrame(cmd: Int, sub: Int, payload: ByteArray = byteArrayOf()): ByteArray {
        val len = payload.size + 5
        val out = ByteArray(payload.size + 9)
        out[0] = 0xDF.toByte()
        out[1] = ((len shr 8) and 0xFF).toByte()
        out[2] = (len and 0xFF).toByte()
        out[3] = 0
        out[4] = (cmd and 0xFF).toByte()
        out[5] = 0x01
        out[6] = (sub and 0xFF).toByte()
        out[7] = ((payload.size shr 8) and 0xFF).toByte()
        out[8] = (payload.size and 0xFF).toByte()
        payload.copyInto(out, 9)
        var sum = 0
        for (b in out) sum = (sum + (b.toInt() and 0xFF)) and 0xFF
        out[3] = sum.toByte()
        return out
    }


    @SuppressLint("MissingPermission") private fun bindAndInfo() {
        val g = gatt ?: run { status.text = "Belum terhubung"; return }
        val c = findChar(UART_WRITE) ?: run { status.text = "6E400002 tidak ditemukan"; return }
        val userId = "267a5a01".toByteArray(Charsets.US_ASCII)
        val bindFrame = makeFrame(0x03, 0x00, userId)
        val infoFrame = makeFrame(0xF3, 0x00)
        appendLog("=== BIND + INFO ===")
        writeFrame(c, bindFrame, "BIND 03 00")
        handler.postDelayed({ writeFrame(c, infoFrame, "INFO F3 00") }, 900)
        status.text = "BIND + INFO dikirim — tunggu balasan..."
    }

    @SuppressLint("MissingPermission") private fun writeFrame(c: BluetoothGattCharacteristic, frame: ByteArray, label: String) {
        val g = gatt ?: return
        val wt = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        c.writeType = wt
        c.value = frame
        val ok = g.writeCharacteristic(c)
        appendLog("$label WRITE ${c.uuid} = ${hex(frame)} | ok=$ok")
    }

    @SuppressLint("MissingPermission") private fun probeDeviceInfo() {
        val g = gatt ?: run { status.text = "Belum terhubung"; return }
        val c = findChar(UART_WRITE) ?: run { status.text = "6E400002 tidak ditemukan"; return }
        val frame = makeFrame(0xF3, 0x00)
        appendLog("=== PROBE INFO PERANGKAT (F3 00) ===")
        appendLog("WRITE ${c.uuid} = ${hex(frame)}")
        val writeType = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        c.writeType = writeType
        c.value = frame
        val ok = g.writeCharacteristic(c)
        appendLog("writeCharacteristic=$ok type=${if (writeType == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) "NO_RESPONSE" else "DEFAULT"}")
        status.text = if (ok) "PROBE terkirim — tunggu balasan Ultra..." else "PROBE gagal dikirim"
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        bt = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        status = findViewById(R.id.tvStatus)
        info = findViewById(R.id.tvInfo)
        connect = findViewById(R.id.btnConnect)
        read = findViewById(R.id.btnRead)
        notify = findViewById(R.id.btnNotify)
        clear = findViewById(R.id.btnClear)
        probe = findViewById(R.id.btnProbe)
        ack = findViewById(R.id.btnAck)
        bind = findViewById(R.id.btnBind)
        val tv = findViewById<TextView>(R.id.tvTime)
        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val list = findViewById<ListView>(R.id.list)
        list.adapter = listAdapter
        findViewById<Button>(R.id.btnScan).setOnClickListener { scan() }
        list.setOnItemClickListener { _, _, p, _ ->
            selected = devs.values.elementAt(p)
            connect.isEnabled = true
            status.text = "Dipilih: ${labels[p]}"
        }
        connect.setOnClickListener { connect() }
        read.setOnClickListener { readAll() }
        notify.setOnClickListener { enableMonitor() }
        clear.setOnClickListener { info.text = "Log dibersihkan." }
        probe.setOnClickListener { probeDeviceInfo() }
        ack.setOnClickListener { probeDeviceInfo() }
        bind.setOnClickListener { bindAndInfo() }
        handler.post(object : Runnable {
            override fun run() {
                tv.text = "Waktu HP: " + SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date())
                handler.postDelayed(this, 1000)
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try { gatt?.close() } catch (_: Exception) {}
    }
}
