# Ultra S9 Protocol Monitor v9.4

Diagnostic build for the Ultra/HryFine BLE protocol.

Flow: connect -> enable 6E400003/FF01 notify -> BIND (03 00, default 8-byte ASCII userId 267a5a01) -> F3 00 device info.

No time-setting or OTA command is included.

The 6E40 protocol structure and bind/device-info sequence are based on publicly documented reverse-engineering notes for HryFine-compatible watches.
