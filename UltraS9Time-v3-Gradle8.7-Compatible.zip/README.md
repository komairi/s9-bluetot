# Ultra S9 Time — v3

Versi ini disesuaikan dengan GitHub Actions yang terlihat pada log pengguna: **Gradle 8.7**.

Perbaikan:
- Android Gradle Plugin 8.6.1 (kompatibel dengan Gradle 8.7)
- Gradle wrapper properties 8.7
- Workflow GitHub Actions menggunakan Gradle 8.7
- Java 17
- Fitur BLE scan, connect, dan pembacaan GATT tetap sama.

Penting:
Project ini belum mengirim command set waktu proprietary ke Ultra S9. Setelah koneksi berhasil, kirim screenshot GATT dari aplikasi agar command set waktu dapat dibuat berdasarkan perangkat yang sebenarnya.
