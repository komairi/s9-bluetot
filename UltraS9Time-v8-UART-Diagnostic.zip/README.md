# Ultra S9 UART Diagnostic v8

Berdasarkan hasil v6/v7, Ultra yang terpilih adalah perangkat paired bernama ULTRA dan GATT-nya memiliki UART-like service:

- Service: 6e400001-b5a3-f393-e0a9-e50e24dcca9f
- Notify: 6e400003-b5a3-f393-e0a9-e50e24dcca9f
- Write: 6e400002-b5a3-f393-e0a9-e50e24dcca9f

Versi ini memprioritaskan characteristic 6e400003 saat tombol NOTIFY ditekan, bukan Battery Level 00002a19.

Langkah:
1. Hubungkan ULTRA.
2. Tekan AKTIFKAN NOTIFY ULTRA (6E400003).
3. Tunggu 20-30 detik.
4. Jika ada NOTIFY HEX, screenshot.
5. Jangan kirim data WRITE dulu.
