# Ultra S9 Time — v4

Perbaikan dari error GitHub Actions v3:

`Inconsistent JVM-target compatibility detected for tasks 'compileDebugJavaWithJavac' (1.8) and 'compileDebugKotlin' (17).`

Sekarang Java dan Kotlin sama-sama ditargetkan ke **JVM 17**.

Konfigurasi:
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Java 17
- Kotlin JVM Toolchain 17
- Java source/target 17

Fitur aplikasi tetap:
- scan BLE
- pilih Ultra S9
- connect
- baca GATT service/characteristic
- tombol SET WAKTU SEKARANG untuk tahap identifikasi protokol

Setelah build berhasil dan aplikasi terpasang, sambungkan Ultra S9 dan kirim screenshot GATT.
