package com.komo.ultras9time

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var adapter: BluetoothAdapter
    private lateinit var scanner: BluetoothLeScanner
    private val handler = Handler(Looper.getMainLooper())
    private var scanning = false
    private var selected: BluetoothDevice? = null
    private var gatt: BluetoothGatt? = null
    private val devices = mutableListOf<BluetoothDevice>()
    private val labels = mutableListOf<String>()
    private lateinit var listAdapter: ArrayAdapter<String>

    private lateinit var tvPhoneTime: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvGatt: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnSet: Button

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val d = result.device
            val name = try { d.name ?: "Nama tidak tersedia" } catch (_: SecurityException) { "Nama tidak tersedia" }
            val text = "$name\n${d.address}   RSSI ${result.rssi}"
            runOnUiThread {
                if (devices.none { it.address == d.address }) {
                    devices.add(d)
                    labels.add(text)
                    listAdapter.notifyDataSetChanged()
                }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { tvStatus.text = "Status: scan gagal ($errorCode)" }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            runOnUiThread {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    tvStatus.text = "Status: TERHUBUNG — membaca service..."
                    btnSet.isEnabled = false
                    g.discoverServices()
                } else {
                    tvStatus.text = "Status: terputus (status $status)"
                    btnSet.isEnabled = false
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val sb = StringBuilder()
            for (s in g.services) {
                sb.append("\nService: ").append(s.uuid).append("\n")
                for (c in s.characteristics) {
                    sb.append("  Characteristic: ").append(c.uuid)
                        .append("  properties=").append(c.properties).append("\n")
                }
            }
            runOnUiThread {
                tvStatus.text = "Status: TERHUBUNG — service ditemukan"
                tvGatt.text = if (sb.isEmpty()) "GATT: tidak ada service" else "GATT:$sb"
                btnSet.isEnabled = true
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            runOnUiThread {
                tvStatus.text = if (status == BluetoothGatt.GATT_SUCCESS)
                    "Status: data waktu berhasil dikirim"
                else "Status: pengiriman gagal ($status)"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        adapter = manager.adapter

        tvPhoneTime = findViewById(R.id.tvPhoneTime)
        tvStatus = findViewById(R.id.tvStatus)
        tvGatt = findViewById(R.id.tvGatt)
        btnConnect = findViewById(R.id.btnConnect)
        btnSet = findViewById(R.id.btnSet)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        findViewById<ListView>(R.id.listDevices).adapter = listAdapter

        findViewById<Button>(R.id.btnScan).setOnClickListener { startScan() }
        findViewById<ListView>(R.id.listDevices).setOnItemClickListener { _, _, pos, _ ->
            selected = devices[pos]
            btnConnect.isEnabled = true
            tvStatus.text = "Dipilih: ${labels[pos]}"
        }
        btnConnect.setOnClickListener { connectSelected() }
        btnSet.setOnClickListener { setTime() }

        handler.post(object : Runnable {
            override fun run() {
                tvPhoneTime.text = "Waktu HP: " + SimpleDateFormat("dd-MM-yyyy  HH:mm:ss", Locale.getDefault()).format(Date())
                handler.postDelayed(this, 1000)
            }
        })
    }

    private fun permissionsOk(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestBtPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(this, arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            ), 10)
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 11)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        if (!permissionsOk()) {
            requestBtPermissions()
            return
        }
        if (!adapter.isEnabled) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }
        if (!adapter.isEnabled) return

        devices.clear()
        labels.clear()
        listAdapter.notifyDataSetChanged()
        scanner = adapter.bluetoothLeScanner
        scanning = true
        tvStatus.text = "Status: mencari perangkat BLE..."
        scanner.startScan(scanCallback)
        handler.postDelayed({
            if (scanning) {
                scanning = false
                scanner.stopScan(scanCallback)
                tvStatus.text = "Status: scan selesai"
            }
        }, 12000)
    }

    @SuppressLint("MissingPermission")
    private fun connectSelected() {
        val d = selected ?: return
        gatt?.close()
        tvStatus.text = "Status: menghubungkan ke ${d.address}..."
        gatt = d.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    @SuppressLint("MissingPermission")
    private fun setTime() {
        val g = gatt ?: return
        val characteristic = findWritableCharacteristic(g)
        if (characteristic == null) {
            tvStatus.text = "Status: belum menemukan karakteristik WRITE. Data jam belum dikirim."
            return
        }

        // Placeholder protocol: banyak Ultra S9 memakai protokol proprietary.
        // Paket ini sengaja tidak mengarang command. Kita hanya menampilkan
        // UUID yang bisa ditulis agar protokol asli dapat diidentifikasi.
        val now = Calendar.getInstance()
        val payload = byteArrayOf(
            (now.get(Calendar.YEAR) - 2000).toByte(),
            (now.get(Calendar.MONTH) + 1).toByte(),
            now.get(Calendar.DAY_OF_MONTH).toByte(),
            now.get(Calendar.HOUR_OF_DAY).toByte(),
            now.get(Calendar.MINUTE).toByte(),
            now.get(Calendar.SECOND).toByte()
        )
        tvStatus.text = "Status: karakteristik WRITE ditemukan (${characteristic.uuid}). Belum mengirim paket karena protokol S9 belum diketahui."
    }

    private fun findWritableCharacteristic(g: BluetoothGatt): BluetoothGattCharacteristic? {
        for (s in g.services) for (c in s.characteristics) {
            val p = c.properties
            if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
                (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) return c
        }
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try { gatt?.close() } catch (_: Exception) {}
    }
}
